# Frontend Consumption — Non-Goals

Defines what frontend usage is explicitly excluded.

## Non-Goals
- Public browsing
- Social sharing
- Frontend editing
- Anonymous access

The system is admin-first by design.
