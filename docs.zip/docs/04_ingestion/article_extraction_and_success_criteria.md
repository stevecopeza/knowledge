# Article Extraction & Ingestion — Architecture and Success Criteria

This document defines **how article extraction is expected to work** and **what constitutes success** within the Knowledge system.

It is normative. Any extraction implementation that violates this document is incorrect, even if it “works”.

---

## 1. Purpose

Article extraction exists to **convert external sources into durable, local knowledge artifacts** while preserving:
- provenance
- structure
- human readability
- long-term usability

Extraction is not scraping for display. It is **knowledge capture for reasoning**.

---

## 2. Extraction Pipeline (Authoritative Stages)

Extraction is a staged pipeline. Each stage has explicit success and failure conditions.

### Stage 1 — Fetch

**Responsibility**
- Retrieve source content at a specific point in time.

**Mechanisms**
- HTTP fetch by default
- JavaScript-capable fetcher when required (optional, capability-based)

**Success Conditions**
- Source content retrieved
- Fetch timestamp recorded
- HTTP status and headers captured

**Failure Conditions**
- Network failure
- Access denied or blocked
- Empty response

A failed fetch produces **no Version**.

---

### Stage 2 — Normalisation

**Responsibility**
- Convert raw source into clean, readable, standalone HTML.

**Required Outcomes**
- Main textual content extracted
- **Core metadata extracted** (at minimum: title, publication date if available, author if available)
- Non-content elements removed (ads, nav, trackers)
- Semantic structure preserved (headings, lists, emphasis)

**Minimum Viability Rule**
If extracted content does not meet minimum thresholds (length, paragraph count, semantic density), normalisation **fails**.

**Failure Conditions**
- Boilerplate-only output (“empty shell”)
- Fragmentary content
- Missing or unusable core metadata (e.g. untitled content with no recoverable context)
- Parser failure

Normalisation failure aborts Version creation.

---

### Stage 3 — Asset Preservation

**Responsibility**
- Preserve meaningful non-text assets locally.

**Scope**
- Images only (by design)

**Success Conditions**
- Each meaningful image downloaded locally
- Image files exceed trivial size threshold
- Valid MIME type confirmed
- HTML references local image paths

Decorative or tracking images may be excluded.

**Failure Conditions**
- Broken image references
- Placeholder-only images
- Zero-byte or invalid files

Partial asset failure results in **degraded success**, not hard failure.

---

### Stage 4 — Storage & Versioning

**Responsibility**
- Persist extracted content as an immutable Version.

**Filesystem Layout**
```
/versions/{uuid}/
  ├── content.html
  └── metadata.json
```

**Metadata Must Include**
- Source URL
- Fetch timestamp
- Content hash
- Extraction warnings (if any)

**Immutability Rule**
Once written, Version artifacts **must never be modified**.

---

## 3. Success Semantics

Success is **not binary**.

### Full Success
- Fetch succeeded
- Normalisation succeeded
- Assets preserved
- Version created without warnings

### Degraded Success
- Core text extracted successfully
- One or more assets failed
- Warnings recorded and surfaced

### Failure
- Fetch or normalisation failed
- No Version created

Failures are explicit and user-visible.

---

## 4. Provenance & Time

Each Version represents:
> “The best possible representation of the source *as fetched at time T*.”

Extraction success is evaluated **relative to that moment**, not against future or ideal states.

---

## 5. User-Visible Outcomes

Users must be able to see:
- Whether ingestion succeeded, degraded, or failed
- What warnings occurred
- What may need review or retry

Silent degradation is forbidden.

---

## 6. Non-Goals (Explicit)

Extraction does **not** aim to:
- Reproduce pixel-perfect layouts
- Preserve interactive widgets
- Capture comments or ads
- Execute arbitrary client-side logic beyond content retrieval

---

## 7. Testing & Verification

Extraction is considered complete only when:
- Automated tests pass
- A human can read the extracted article comfortably
- Images render locally
- No silent errors are present

If extraction fails more than **5 consecutive attempts**, retries must stop and an explanation must be produced.

---

## Closing Rule

If an extraction result cannot be trusted by a human reader, it is a failure — regardless of technical success.
