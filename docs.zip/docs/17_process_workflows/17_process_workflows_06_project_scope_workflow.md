# Process Workflow — Project Membership & Scope

## Purpose
Define how Projects determine context.

## Workflow Steps
1. Add or remove knowledge references
2. Recalculate Project scope
3. Update search and AI boundaries

## Rules
- No duplication of content

## Outcome
- Stable, explicit research context

