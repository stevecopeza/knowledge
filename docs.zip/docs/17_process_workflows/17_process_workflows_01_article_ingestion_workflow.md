# Process Workflow — Article Ingestion

## Purpose
Define the exact system steps for ingesting a single article safely and deterministically.

## Trigger
- User submits a URL (UI or API)

## Workflow Steps
1. Validate URL and permissions
2. Create ingestion job (Queued)
3. Fetch source content
4. Normalise HTML and extract metadata
5. Download and optimise media
6. Compute content hash
7. Deduplication check
8. Create Article (if new)
9. Create immutable Version
10. Mark job Completed or Failed

## Failure Handling
- Network or parse failure → job Failed, visible to user
- Duplicate detected → reuse existing Article/Version

## Outcome
- Article available for annotation and organisation

