# Process Workflow — AI Output Acceptance

## Purpose
Ensure humans retain authority over AI output.

## Workflow Steps
1. Store AI output as draft
2. Present to user
3. User accepts, edits, or discards
4. Accepted output becomes canonical artifact

## Outcome
- No silent AI promotion

