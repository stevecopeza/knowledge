# Installation and First-Run Behavior

Defines plugin activation behavior.

## Activation
- Prepare database
- Create directories
- No auto-content

## Defaults
- AI disabled
- No default categories

The system becomes useful after first ingestion.
